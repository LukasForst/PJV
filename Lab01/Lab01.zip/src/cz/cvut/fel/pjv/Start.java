package cz.cvut.fel.pjv;

/*
 * Created by lukas on 22.2.17.
 */
public class Start {

    public static void main(String[] args) {
        Lab01 lab = new Lab01();
        lab.start(args);
    }

}
